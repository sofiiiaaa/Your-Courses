/**
3. **Find the smallest number in array**
 * This function takes an array of numbers as input and returns the smallest number in the array.
 * @param {number[]} array - The array of numbers.
 */
function findSmallestNumber(array) {
    // Your code here
}

module.exports = findSmallestNumber;
