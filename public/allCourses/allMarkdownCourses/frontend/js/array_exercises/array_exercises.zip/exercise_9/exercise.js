/**
3. **Find duplicates in an array**
 * This function takes an array as input and returns a new array that contains the duplicate elements of the input array.
 * @param {Array} array - The array to be checked.
 */
function findDuplicates(array) {
    // Your code here
}

module.exports = findDuplicates;
