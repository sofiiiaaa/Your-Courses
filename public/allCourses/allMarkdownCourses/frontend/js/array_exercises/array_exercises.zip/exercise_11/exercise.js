/**
5. **Flatten a multidimensional array**
 * This function takes a multidimensional array as input and returns a new one-dimensional array that contains all the elements of the input array.
 * @param {Array} array - The multidimensional array to be flattened.
 */
function flattenArray(array) {
    // Your code here
}

module.exports = flattenArray;
