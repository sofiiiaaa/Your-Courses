/**
8. **Transform an array of strings to uppercase**
 * This function takes an array of strings as input and returns a new array where all the strings are converted to uppercase.
 * @param {string[]} array - The array of strings to be converted.
 */
function toUpperCase(array) {
    // Your code here
}

module.exports = toUpperCase;
