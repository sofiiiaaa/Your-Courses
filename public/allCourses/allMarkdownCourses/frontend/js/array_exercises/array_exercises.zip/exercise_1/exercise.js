/**
1. **Sum of all numbers in array**
 * This function takes an array of numbers as input and returns the sum of all the numbers in the array.
 * @param {number[]} array - The array of numbers.
 */
function sumArray(array) {
    // Your code here
}

module.exports = sumArray;
