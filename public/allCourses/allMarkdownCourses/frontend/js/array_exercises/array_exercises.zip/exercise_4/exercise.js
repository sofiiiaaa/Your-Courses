/**
4. **Find the longest string in array**
 * This function takes an array of strings as input and returns the longest string in the array.
 * @param {string[]} array - The array of strings.
 */
function findLongestString(array) {
    // Your code here
}

module.exports = findLongestString;
