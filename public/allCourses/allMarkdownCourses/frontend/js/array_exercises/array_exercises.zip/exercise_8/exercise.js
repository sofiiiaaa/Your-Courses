/**
2. **Find the common elements of two arrays**
 * This function takes two arrays as input and returns a new array that contains the common elements of the input arrays.
 * @param {Array} array1 - The first array.
 * @param {Array} array2 - The second array.
 */
function findCommonElements(array1, array2) {
    // Your code here
}

module.exports = findCommonElements;
