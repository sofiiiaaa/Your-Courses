/**
1. **Merge two arrays**
 * This function takes two arrays as input and returns a new array that is the result of merging the two input arrays.
 * @param {Array} array1 - The first array.
 * @param {Array} array2 - The second array.
 */
function mergeArrays(array1, array2) {
    // Your code here
}

module.exports = mergeArrays;
