/**
2. **Count the number of boolean values in array**
 * This function takes an array as input and returns the count of boolean values in the array.
 * @param {any[]} array - The array to be checked.
 */
function countBooleans(array) {
    // Your code here
}

module.exports = countBooleans;
