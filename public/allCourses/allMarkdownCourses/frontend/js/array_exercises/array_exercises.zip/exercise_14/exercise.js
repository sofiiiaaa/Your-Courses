/**
9. **Find the maximum and minimum values in an array of numbers**
 * This function takes an array of numbers as an input and returns an object with the maximum and minimum numbers extracted from the array.
 * @param {number[]} array - The array of numbers.
 */
function findMaxMin(array) {
    // Your code here
}

module.exports = findMaxMin;
