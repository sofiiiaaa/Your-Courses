/**
 * 15. **Check if a String Starts with a Specific Word**
 * This function takes a string and a word, and returns true if the string starts with the word, false otherwise.
 * @param {string} str - The string to check.
 * @param {string} word - The word to check for.
 */
 function startsWithWord(str, word) {
    // Your code here
}

module.exports = startsWithWord;
