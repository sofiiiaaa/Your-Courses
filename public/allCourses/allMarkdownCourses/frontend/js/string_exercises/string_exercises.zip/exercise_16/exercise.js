/**
 * 16. **printWithoutFirstAndLast**
 * This function takes a string x and prints the string composed of all characters of x except the first one,
 * followed by all characters of x except the last one.
 * @param {string} x - The input string.
 */
 function printWithoutFirstAndLast(x) {
    // Your code here
}

module.exports = printWithoutFirstAndLast;
