/**
 * 17. **Extract and Print First and Last 3 Characters**
 * This function takes a string x and extracts its last 3 characters joined to the first 3 characters, then prints the result.
 * @param {string} x - The input string (must be at least 3 characters long).
 */
 function extractAndPrintFirstAndLastThree(x) {
    // Your code here
}
module.exports = extractAndPrintFirstAndLastThree;
