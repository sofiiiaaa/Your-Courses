/**
 * 21. **Print String with Mid-Character in Lowercase**
 * This function takes a string 'x' of odd length and prints a new string like 'x' with the mid-character in lowercase.
 * @param {string} x - The input string of odd length.
 */
 function printStringWithLowercaseMidCharacter(x) {
    // Your code here
}

module.exports = printStringWithLowercaseMidCharacter;
