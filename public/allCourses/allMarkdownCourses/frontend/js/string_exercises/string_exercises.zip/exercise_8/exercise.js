/**
 * 8. **Count Occurrences of a Word in a String**
 * This function takes a string and a word, and returns the count of occurrences of the word in the string.
 * @param {string} str - The string in which the word is to be counted.
 * @param {string} word - The word to count.
 */
 function countOccurrences(str, word) {
    // Your code here
}

module.exports = countOccurrences;
