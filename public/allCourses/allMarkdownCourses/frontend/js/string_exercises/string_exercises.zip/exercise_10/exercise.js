/**
 * 10. **Convert String to Camel Case**
 * This function takes a string as input and returns the string in camel case.
 * @param {string} str - The string to be converted to camel case.
 */
 function toCamelCase(str) {
    // Your code here
}

module.exports = toCamelCase;
