/**
 * 6. **Replace All Occurrences of a Word in a String**
 * This function takes a string, a word to find, and a word to replace with, and returns the string with all occurrences of the word replaced.
 * @param {string} str - The string in which the word is to be replaced.
 * @param {string} find - The word to find.
 * @param {string} replace - The word to replace with.
 */
 function replaceAll(str, find, replace) {
    // Your code here
}

module.exports = replaceAll;
