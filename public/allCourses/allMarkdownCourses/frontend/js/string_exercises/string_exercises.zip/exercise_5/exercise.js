/**
 * 5. **Find Longest Word in a String**
 * This function takes a string as input and returns the longest word in the string.
 * @param {string} str - The string from which the longest word is to be found.
 */
 function findLongestWord(str) {
    // Your code here
}

module.exports = findLongestWord;
