/**
 * **Check if String is Palindrome**
 * This function takes a string as input and returns true if the string is a palindrome, false otherwise.
 * @param {string} str - The string to be checked.
 */
 function isPalindrome(str) {
    // Your code here
}

module.exports = isPalindrome;
