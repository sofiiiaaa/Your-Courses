/**
 * 14. **Extract a Substring from a String**
 * This function takes a string, a start index, and an end index, and returns the substring from the start index to the end index.
 * @param {string} str - The string from which the substring is to be extracted.
 * @param {number} start - The start index.
 * @param {number} end - The end index.
 */
 function extractSubstring(str, start, end) {
    // Your code here
}

module.exports = extractSubstring;
