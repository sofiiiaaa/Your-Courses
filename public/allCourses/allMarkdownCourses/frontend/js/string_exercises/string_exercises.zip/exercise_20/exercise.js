/**
 * 20. **Repeat syllabe N times**
 * This function takes a syllable and a phrase ending with a digit 'n' and prints the syllable repeated 'n' times, separated by spaces.
 * @param {string} syllable - The syllable to be repeated.
 * @param {string} phrase - The phrase ending with a digit 'n'.
 */
 function repeatSyllableNTimes(syllable, phrase) {
    // Your code here
}

module.exports = repeatSyllableNTimes;
