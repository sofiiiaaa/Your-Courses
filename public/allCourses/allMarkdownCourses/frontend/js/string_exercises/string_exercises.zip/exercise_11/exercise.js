/**
 * 11. **Split a String into an Array of Words**
 * This function takes a string as input and returns an array of words in the string.
 * @param {string} str - The string to be split into words.
 */
 function splitIntoWords(str) {
    // Your code here
}

module.exports = splitIntoWords;
