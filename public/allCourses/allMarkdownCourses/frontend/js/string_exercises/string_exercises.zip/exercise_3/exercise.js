/**
 * 3. **Count Vowels in a String**
 * This function takes a string as input and returns the count of vowels in the string.
 * @param {string} str - The string in which vowels are to be counted.
 */
 function countVowels(str) {
    // Your code here
}


module.exports = countVowels;
