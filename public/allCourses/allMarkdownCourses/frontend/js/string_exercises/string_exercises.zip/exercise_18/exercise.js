/**
 * .18. **Replace Substrings in a String**
 * This function replaces the substring 'Gold' with the string in the variable what,
 * and replaces the substring 'has begun' with the string in the variable happened.
 * @param {string} s - The input string.
 * @param {string} what - The string to replace 'Gold' with.
 * @param {string} happened - The string to replace 'has begun' with.
 */
 function replaceSubstrings(s, what, happened) {
    // Your code here
}

module.exports = replaceSubstrings;
