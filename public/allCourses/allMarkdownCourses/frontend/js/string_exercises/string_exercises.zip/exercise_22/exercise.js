/**
 * 22. **Check if x and y Start with z**
 * This function takes three strings 'x', 'y', and 'z', and prints True if both 'x' and 'y' start with string 'z', otherwise prints False.
 * @param {string} x - The first input string.
 * @param {string} y - The second input string.
 * @param {string} z - The string to check if 'x' and 'y' start with.
 */
 function checkIfStartsWithZ(x, y, z) {
    // Your code here
}

module.exports = checkIfStartsWithZ
