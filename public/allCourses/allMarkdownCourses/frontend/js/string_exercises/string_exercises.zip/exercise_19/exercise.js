/**
 * 19. **Check if a Word Begins and Ends with the Same Two Characters**
 * This function checks if a word begins with the same two characters it ends with and returns true if so, false otherwise.
 * @param {string} word - The input word.
 * @returns {boolean} - True if the word meets the condition, false otherwise.
 */
 function beginsAndEndsWithSameTwoChars(word) {
    // Your code here
}

module.exports = beginsAndEndsWithSameTwoChars;
