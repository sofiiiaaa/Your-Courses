/**
 *
 * 7. **Convert String to Title Case**
 * This function takes a string as input and returns the string in title case.
 * @param {string} str - The string to be converted to title case.
 */
 function toTitleCase(str) {
    // Your code here
}

module.exports = toTitleCase;
