/**
 * 13. **Convert a String to a URL Slug**
 * This function takes a string as input and returns a URL-friendly slug.
 * @param {string} str - The string to be converted to a slug.
 */
 function toSlug(str) {
    // Your code here
}

module.exports = toSlug;
