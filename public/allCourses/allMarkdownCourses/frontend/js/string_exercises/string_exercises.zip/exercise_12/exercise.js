/**
 * 12. **Remove Extra Spaces from a String**
 * This function takes a string as input and returns the string with extra spaces removed.
 * @param {string} str - The string from which extra spaces are to be removed.
 */
 function removeExtraSpaces(str) {
    // Your code here
}
module.exports  = removeExtraSpaces;
