/**
 * 23. **isValidPhoneNumber**
 * This function checks if a given string is a valid phone number of the format +39XXXXXXXXXX.
 * @param {string} str - The input string to check.
 * @returns {boolean} - True if the string is a valid phone number, false otherwise.
 */
 function isValidPhoneNumber(str) {
    // Your code here
}

module.exports = isValidPhoneNumber
