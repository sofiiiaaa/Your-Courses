/**
 * 9. **Check if String Contains a Word**
 * This function takes a string and a word, and returns true if the string contains the word, false otherwise.
 * @param {string} str - The string to check.
 * @param {string} word - The word to find.
 */
 function containsWord(str, word) {
    // Your code here
}
module.exports = containsWord;
