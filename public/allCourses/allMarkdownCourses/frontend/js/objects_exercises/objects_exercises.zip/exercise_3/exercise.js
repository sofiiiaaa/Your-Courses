/**
4. **Sum of number values in object**
 * This function takes an object as input and returns the sum of all the number values in the object.
 * @param {object} obj - The object to be checked.
 */
function sumNumberValues(obj) {
    // Your code here
}

module.exports = sumNumberValues;
