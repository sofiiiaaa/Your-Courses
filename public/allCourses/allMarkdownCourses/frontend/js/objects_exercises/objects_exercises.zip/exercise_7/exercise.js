/**
7. **Count the number of boolean values in object**
 * This function takes an object as input and returns the count of boolean values in the object.
 * @param {object} obj - The object to be checked.
 */
function countBooleans(obj) {
    // Your code here
}

module.exports = countBooleans;
