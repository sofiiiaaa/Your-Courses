/**
 * This function takes an object as input and returns the longest string value in the object.
 * @param {object} obj - The object to be checked.
 */
function findLongestString(obj) {
    // Your code here
}

module.exports = findLongestString;
