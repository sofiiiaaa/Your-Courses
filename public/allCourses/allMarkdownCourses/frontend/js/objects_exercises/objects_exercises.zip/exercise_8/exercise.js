/**
8. **Find the smallest number in object**
 * This function takes an object as input and returns the smallest number value in the object.
 * @param {object} obj - The object to be checked.
 */
function findSmallestNumber(obj) {
    // Your code here
}

module.exports = findSmallestNumber;
