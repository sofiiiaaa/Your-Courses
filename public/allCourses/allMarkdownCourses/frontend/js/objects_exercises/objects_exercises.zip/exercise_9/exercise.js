/**
9. **Reverse all strings in object**
 * This function takes an object as input and returns a new object with all the string values reversed.
 * @param {object} obj - The object to be checked.
 */

function reverseStrings(obj) {
    // Your code here
}

module.exports = reverseStrings;
