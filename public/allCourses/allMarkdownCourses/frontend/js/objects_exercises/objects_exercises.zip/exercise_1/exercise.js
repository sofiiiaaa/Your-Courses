/**
2. **String concatenation from object**
 * This function takes an object as input and concatenates all the string values in the object.
 * @param {object} obj - The object to be checked.
 */
function concatenateStrings(obj) {
    // Your code here
}

module.exports = concatenateStrings;
