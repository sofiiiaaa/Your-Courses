/**
5. **Check if a value exists in array**
 * This function takes an array and a value as input and returns true if the value exists in the array, and false otherwise.
 * @param {any[]} array - The array to be checked.
 * @param {string|number|boolean} value - The value to be checked.
 */
function valueExists(array, value) {
    // Your code here
}

module.exports = valueExists;
