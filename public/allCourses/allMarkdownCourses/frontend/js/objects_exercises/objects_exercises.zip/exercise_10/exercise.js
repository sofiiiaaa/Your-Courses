/**
10. **Check if a key exists in object**
 * This function takes an object and a key as input and returns true if the key exists in the object, and false otherwise.
 * @param {object} obj - The object to be checked.
 * @param {string} key - The key to be checked.
 */
function keyExists(obj, key) {
    // Your code here
}

module.exports = keyExists;
