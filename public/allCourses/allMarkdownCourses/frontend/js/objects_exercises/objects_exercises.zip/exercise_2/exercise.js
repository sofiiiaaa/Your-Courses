/**
3. **Check boolean values in object**
 * This function takes an object as input and returns true if all values in the object are true, and false otherwise.
 * @param {object} obj - The object to be checked.
 */
function checkAllTrue(obj) {
    // Your code here
}

module.exports = checkAllTrue;
